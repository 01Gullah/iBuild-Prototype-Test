# Product Screen Inventory

| Area | Screens to complete |
|---|---|
| Access | Sign-in, invitation, recovery, organisation selection, denied state |
| Management | Portfolio, project health, commercial summary, management actions |
| Operations | Assigned-project overview, schedule, progress, tasks, reviews |
| Team Workspace | My tasks, instructions, documents, submissions, feedback/history |
| Projects | List, create wizard, overview, team/access, milestones, documents, activity |
| BoQ Intelligence | Upload, import status, extraction review, item editor, source comparison, validation, versions, submit/approve |
| Cost Management | Baseline, cost codes, commitments, expenses, variations, forecast, approvals |
| Materials & Procurement | Requirements, requisition, supplier, purchase, receiving, inventory, issuance, consumption, wastage, reconciliation |
| Tasks & Site Operations | Work breakdown, task detail, assignment, daily update, evidence, inspection, review/return/approve |
| Insights & Analytics | Portfolio, progress, cost, materials, productivity, schedule, risks, comparisons, drill-down |
| Risks & Issues | Register, risk detail, matrix, issue log, mitigation, delay view, action history |
| Reports & Documents | Report library/builder, document register/detail/version, export/print |
| Settings | Profile, organisation, project settings, members, permissions, notifications, audit |
| Help | Help centre, glossary, workflow guides, support |
| Later | Controlled Team Performance View: scoped, read-only, expiring, revocable, audited |

Every screen needs desktop/tablet/mobile behaviour, loading/empty/error/denied states, validation, clear actions and accessible controls. Wide tables need mobile card or prioritised layouts.
