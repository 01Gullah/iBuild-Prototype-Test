# Frontend Engineer Handoff — iBuild InfraMent

## Purpose
Clickable first-pass reference for the intended product experience. It is not production-ready functionality.

## Approved visual tokens
Deep Teal `#063F3D`; Deep Evergreen `#052F2E`; Rich Gold `#D9A21B`; Warm Gold `#E8B64A`; Soft Cool White `#F4F6F8`; White `#FFFFFF`; Charcoal Navy `#17212F`; Slate `#667085`; Light Grey `#E4E8EC`; semantic Green `#15956F`, Amber `#E7A323`, Red `#D94841`, Blue `#3478B8`.

## Product rules
- Simple at first glance, powerful when explored.
- Design the complete product as one coherent experience; phases sequence implementation, not separate launches or redesigns.
- Mobile-first, plain-language, progressive disclosure and accessible controls.
- No sample data presented as live. No false success messages.
- Server enforces every permission; frontend visibility is not security.
- Management Dashboard, Operational Dashboard and Team Workspace are distinct experience patterns. Effective permissions are identity-, organisation- and project-scoped. View/create/edit/submit/review/approve/export/administer are distinct permissions.

## Module scope
Dashboard; project creation/setup/workspace; BoQ Intelligence; Cost Management; Materials & Procurement; Tasks & Site Operations; Insights & Analytics; Risks & Issues; Reports & Documents; Settings; Help & Support; later controlled Team Performance View.

## First operational workflow
Project setup → Excel/digital PDF BoQ intake → extraction and standardisation → source review/correction → calculation validation → professional approval → approved cost baseline. Only approved BoQ versions establish the official baseline.

## Required screen states
Loading, first-use empty, no-results, validation errors, recoverable errors, server/network failure, permission denied without data leakage, confirmed success only after server response, stale/last-updated where relevant.

## Architecture cautions
Intended direction is React + Vite, Apps Script backend, Sheets initial data store, Drive documents and GitHub. Validate the actual deployment topology. `google.script.run` only exists in Apps Script HTML Service; it is unavailable to a separately hosted Vite app. Use a transport/service adapter. No secrets in browser. Validate auth/session, tenant/project isolation, file access, API contracts, environment separation, backups and rollback before production connection.

## Completion policy
A designed screen is not an implemented feature. Full release requires complete scope integration, end-to-end tests, security review, documentation and approval by both founders. No phase is a public launch by itself.
