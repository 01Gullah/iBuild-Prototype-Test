# iBuild InfraMent — Interactive React Prototype v0.1

A clickable React/Vite interface reference. It is NOT the production application and has no authentication, API, database, real document processing or server-enforced permissions. All records, metrics and chart-like summaries are illustrative.

## Run
Requires Node.js and npm. Run `npm install`, then `npm run dev`. Use the local URL printed by Vite. Run `npm run build` to verify a production bundle.

## Included
Responsive application shell; Management, Project Manager, Site Engineer and Worker preview roles; all primary module navigation; dashboard; project cards and filters; module Overview/Records/Activity tabs; preview modals and feedback; sample-data notices; cost-area restricted preview.

## Handoff
See `HANDOFF_FOR_FRONTEND_ENGINEER.md` and `PRODUCT_SCREEN_INVENTORY.md`. Treat this as a visual/interaction reference and starter, not a finished feature set. Replace sample fixtures with typed domain models and API adapters only after backend contracts and authentication/authorisation are agreed. `google.script.run` is only available inside Apps Script HTML Service, not a separately hosted React/Vite app. Never use frontend-only role hiding as security.
